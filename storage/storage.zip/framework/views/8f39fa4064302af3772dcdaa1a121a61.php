<?php $__env->startSection('title'); ?>
    <?php echo e('Dashboard'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="user-info mb-50">
        <h1 class="fs-37">
            <span class="left-text text-capitalize fw-light"><?php echo e(greeting()); ?> </span>
            <span class="right-text text-capitalize"><?php echo e($current_user); ?></span>
        </h1>

    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="mb-0"><?php echo e(__('dashboard.lbl_performance')); ?></h3>
                <div class="d-flex  align-items-center">
                    
                    <form id="dateRangeForm" class="d-flex align-items-center gap-2">
                        <div class="form-group my-0 ms-3 d-flex gap-3">
                            <input type="text" name="date_range" id="revenuedateRangeInput" value="<?php echo e($date_range); ?>"
                                class="form-control dashboard-date-range" placeholder="<?php echo e(__('messages.Select_Date')); ?>"
                                readonly="readonly">
                            <a href="<?php echo e(route('backend.home')); ?>" class="btn btn-primary" id="refreshRevenuechart"
                                title="<?php echo e(__('appointment.reset')); ?>" data-bs-placement="top" data-bs-toggle="tooltip">
                                <i class="ph ph-arrow-counter-clockwise"></i>
                            </a>
                            <button type="submit" name="action" value="filter" class="btn btn-secondary"
                                data-bs-toggle="tooltip" data-bs-title="<?php echo e(__('messages.submit_date_filter')); ?>"
                                id="submitBtn" disabled><?php echo e(__('dashboard.lbl_submit')); ?></button>
                        </div>
                    </form>

                </div>
            </div>
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-sm-6 col-lg-4">
                            <a href="<?php echo e(route('backend.appointments.index')); ?>" class="text-secondary">
                                <div class="card dashboard-cards appointments">
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo e(__('appointment.total_number_appointment')); ?> </p>
                                        <div class="d-flex align-items-center justify-content-between gap-3 mt-5">
                                            <h2 class="mb-0" id="total_booking_count"><?php echo e($data['total_appointments']); ?>

                                            </h2>
                                            <img src="<?php echo e(asset('img/dashboard/clender.png')); ?>" alt="image">
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-sm-6 col-lg-4">
                            <a href="<?php echo e(route('backend.services.index')); ?>" class="text-secondary">
                                <div class="card dashboard-cards appointments">
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo e(__('dashboard.total_active_service')); ?></p>
                                        <div class="d-flex align-items-center justify-content-between gap-3 mt-5">
                                            <h2 class="mb-0" id="total_active_service_count">
                                                <?php echo e($data['total_clinicservice']); ?></h2>
                                            <img src="<?php echo e(asset('img/dashboard/services.png')); ?>" alt="image">
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php if(multiVendor() == '1' && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
                            <div class="col-sm-6 col-lg-4">
                                <a href="<?php echo e(route('backend.multivendors.index')); ?>" class="text-secondary">
                                    <div class="card dashboard-cards appointments">
                                        <div class="card-body">
                                            <p class="mb-0"><?php echo e(__('dashboard.total_active_vendors')); ?></p>
                                            <div class="d-flex align-items-center justify-content-between gap-3 mt-5">
                                                <h2 class="mb-0" id="total_active_vendor_count">
                                                    <?php echo e($data['totalactivevendor']); ?></h2>
                                                <img src="<?php echo e(asset('img/dashboard/active-vendor.png')); ?>" alt="image">
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endif; ?>
                        <div class="col-sm-6 col-lg-4">
                            <a href="<?php echo e(route('backend.clinics.index')); ?>" class="text-secondary">
                                <div class="card dashboard-cards appointments">
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo e(__('dashboard.total_clinics')); ?></p>
                                        <div class="d-flex align-items-center justify-content-between gap-3 mt-5">
                                            <h2 class="mb-0"><?php echo e($data['total_clinics']); ?></h2>
                                            <img src="<?php echo e(asset('img/dashboard/product-sale.png')); ?>" alt="image">
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-sm-6 <?php echo e(multivendor() == 1 ? 'col-lg-4' : 'col-lg-6'); ?>">
                            <a href="<?php echo e(route('backend.customers.index')); ?>" class="text-secondary">
                                <div class="card dashboard-cards appointments">
                                    <div class="card-body">
                                        <p class="mb-0"><?php echo e(__('dashboard.total_users')); ?></p>
                                        <div class="d-flex align-items-center justify-content-between gap-3 mt-5">
                                            <h2 class="mb-0" id="total_user"><?php echo e($data['total_user']); ?></h2>
                                            <img src="<?php echo e(asset('img/dashboard/users.png')); ?>" alt="image">
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-sm-6 <?php echo e(multivendor() == 1 ? 'col-lg-4' : 'col-lg-6'); ?>">
                            <div class="card dashboard-cards appointments">
                                <div class="card-body">
                                    <p class="mb-0"><?php echo e(__('dashboard.total_revenue')); ?></p>
                                    <div class="d-flex align-items-center justify-content-between gap-3 mt-5">
                                        <h2 class="mb-0" id="total_revenue_amount">
                                            <?php echo e(Currency::format($data['total_revenue'])); ?></h2>
                                        <img src="<?php echo e(asset('img/dashboard/revenue.png')); ?>" alt="image">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card card-block card-height">
                        <div class="card-header mb-5">
                            <h4 class="card-title mb-0"><?php echo e(__('dashboard.visited_patient')); ?></h4>
                        </div>
                        <div class="card-body pt-0">
                            <div class="d-flex align-items-end h-100">
                                <div class="d-flex align-items-end flex-grow-1">
                                    <div class="text-center flex-grow-1">
                                        <img src="<?php echo e(asset('img/dashboard/girl-and-boy-age-0-20.png')); ?>"
                                            class="img-fluid" alt="age-image-0-20">
                                        <h6 class="mb-0 mt-2 fw-normal"><?php echo app('translator')->get('messages.0_25_age'); ?></h6>
                                        <div class="mt-4 pt-3 border-top">
                                            <h6 class="mb-0" id="child_patient_count">
                                                <?php echo e($data['child_patient_count']); ?></h6>
                                        </div>
                                    </div>
                                    <div class="text-center flex-grow-1">
                                        <img src="<?php echo e(asset('img/dashboard/girl-and-boy-age-20-40.png')); ?>"
                                            class="img-fluid" alt="age-image-0-20">
                                        <h6 class="mb-0 mt-2 fw-normal"><?php echo app('translator')->get('messages.26_50_age'); ?></h6>
                                        <div class="mt-4 pt-3 border-top">
                                            <h6 class="mb-0" id="adult_patient_count">
                                                <?php echo e($data['adult_patient_count']); ?></h6>
                                        </div>
                                    </div>
                                    <div class="text-center flex-grow-1">
                                        <img src="<?php echo e(asset('img/dashboard/girl-and-boy-age-40-80.png')); ?>"
                                            class="img-fluid" alt="age-image-0-20">
                                        <h6 class="mb-0 mt-2 fw-normal"><?php echo app('translator')->get('messages.50+_age'); ?></h6>
                                        <div class="mt-4 pt-3 border-top">
                                            <h6 class="mb-0" id="old_patient_count"><?php echo e($data['old_patient_count']); ?>

                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xxl-8 col-lg-7 col-md-6">
            <div class="card card-block card-stretch card-height">
                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
                    <h4 class="card-title mb-0"><?php echo e(__('dashboard.lbl_tot_revenue')); ?></h4>
                    <div id="date_range" class="dropdown d-none">
                        
                        <a href="#" class="dropdown-toggle btn text-body bg-body border total_revenue"
                            id="dropdownTotalRevenue" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo e(__('dashboard.year')); ?>

                            <svg width="8" class="ms-1 transform-up" viewBox="0 0 12 8" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M6 5.08579L10.2929 0.792893C10.6834 0.402369 11.3166 0.402369 11.7071 0.792893C12.0976 1.18342 12.0976 1.81658 11.7071 2.20711L6.70711 7.20711C6.31658 7.59763 5.68342 7.59763 5.29289 7.20711L0.292893 2.20711C-0.0976311 1.81658 -0.0976311 1.18342 0.292893 0.792893C0.683418 0.402369 1.31658 0.402369 1.70711 0.792893L6 5.08579Z"
                                    fill="currentColor"></path>
                            </svg>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-soft-primary sub-dropdown"
                            aria-labelledby="dropdownTotalRevenue">
                            <li><a class="revenue-dropdown-item dropdown-item"
                                    data-type="Year"><?php echo e(__('dashboard.year')); ?></a></li>
                            <li><a class="revenue-dropdown-item dropdown-item"
                                    data-type="Month"><?php echo e(__('dashboard.month')); ?></a></li>
                            <li><a class="revenue-dropdown-item dropdown-item"
                                    data-type="Week"><?php echo e(__('dashboard.week')); ?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body pt-0">
                    <div id="total-revenue"></div>
                </div>
            </div>
        </div>
        <div class="col-xxl-4 col-lg-5 col-md-6">
            <div class="card card-block card-stretch card-height">
                <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
                    <h4 class="card-title mb-0"><?php echo e(__('dashboard.lbl_upcoming_appointment')); ?> </h4>
                    <?php if(count($data['upcomming_appointments']) >= 5): ?>
                        <a id="appointment_view_all_link" href="<?php echo e(route('backend.appointments.index')); ?>"
                            class="text-secondary d-none"><?php echo e(__('dashboard.view_all')); ?></a>
                    <?php endif; ?>
                </div>
                <div class="card-body pt-0">
                    <div class="upcoming-appointments">
                        <ul id="upcoming-appointments" class="list-inline p-0 m-0">
                            <?php $__empty_1 = true; $__currentLoopData = $data['upcomming_appointments']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcomming_appointments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="mb-3">
                                    <div class="bg-body p-3 rounded-3">
                                        <div class="row align-items-center">
                                            <div class="col-3">
                                                <p class="mb-0 text-primary">
                                                    <?php echo e(date($data['dateformate'], strtotime($upcomming_appointments->appointment_date))); ?>

                                                </p>
                                                <span class="mb-0 text-primary">
                                                    <?php echo e($upcomming_appointments->appointment_time
                                                        ? \Carbon\Carbon::parse($upcomming_appointments->appointment_time)->timezone($timeZone)->format($data['timeformate'])
                                                        : '--'); ?>

                                                </span>
                                            </div>
                                            <div class="col-8 ps-0">
                                                <div class="border-start border-light ps-4 ms-sm-4">
                                                    <h6 class="mb-0">
                                                        <?php echo e(optional($upcomming_appointments->user)->full_name); ?></h6>
                                                    <p><?php echo e(__('clinic.lbl_clinic_name')); ?>:
                                                        <?php echo e(optional($upcomming_appointments->cliniccenter)->name); ?></p>
                                                    <span><?php echo e(optional($upcomming_appointments->clinicservice)->name); ?> By
                                                        <b><?php echo e(optional($upcomming_appointments->doctor)->full_name); ?></b></span>
                                                </div>
                                            </div>
                                            <div class="col-1 px-0">
                                                <a href="<?php echo e(route('backend.appointments.clinicAppointmentDetail', ['id' => $upcomming_appointments->id])); ?>"
                                                    class="text-body">
                                                    <i class="ph ph-caret-right transform-icon"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-center"><?php echo e(__('dashboard.no_data_available')); ?></li>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php if(multiVendor() == '1' && (auth()->user()->hasRole('admin') || auth()->user()->hasRole('demo_admin'))): ?>
            <div class="col-xxl-4 col-lg-5 col-md-6">
                <div class="card card-block card-stretch card-height">
                    <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
                        <h4 class="card-title mb-0"><?php echo e(__('dashboard.register_vendor')); ?> </h4>
                        <?php if(count($data['register_vendor']) >= 4): ?>
                            <a id="vendor_view_all_link" href="<?php echo e(route('backend.multivendors.index')); ?>"
                                class="text-secondary d-none" contenteditable="false"
                                style="cursor: pointer;"><?php echo e(__('dashboard.view_all')); ?></a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body pt-0">
                        <ul id="register_vendors_list" class="list-inline m-0 p-0 register-vendors-list">

                            <?php $__empty_1 = true; $__currentLoopData = $data['register_vendor']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $register_vendors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li class="mb-3">
                                    <div
                                        class="bg-body d-flex align-items-center justify-content-between p-3 rounded-3 gap-3 flex-sm-row flex-column">
                                        <div
                                            class="d-flex align-items-center gap-3 flex-sm-row flex-lg-nowrap flex-md-wrap flex-column flex-nowrap">
                                            <div class="image flex-shrink-0">
                                                <img src="<?php echo e($register_vendors->profile_image ?? default_user_avatar()); ?>"
                                                    class="avatar-50 rounded-circle" alt="user-image">
                                            </div>
                                            <div class="text-sm-start text-center">
                                                <h6 class="mb-0"><?php echo e($register_vendors->full_name); ?></h6>
                                                <small
                                                    class="m-0"><?php echo e(date($data['dateformate'], strtotime($register_vendors->created_at))); ?>

                                                    At
                                                    <?php echo e(date($data['timeformate'], strtotime($register_vendors->created_at))); ?></small>
                                            </div>
                                        </div>
                                        <div class="flex-shrink-0">
                                            <span class="badge bg-success-subtle p-2">
                                                <?php echo e($register_vendors->email_verified_at !== null ? __('messages.verified') : __('messages.unverified')); ?>

                                            </span>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li class="text-center"><?php echo e(__('dashboard.no_data_available')); ?></li>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(multiVendor() == '0'): ?>
            <div class="col-xxl-12 col-lg-12 col-md-12">
            <?php else: ?>
                <div class="col-xxl-8 col-lg-7 col-md-6">
        <?php endif; ?>
        <div class="card card-block card-stretch card-height">
            <div class="card-header d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
                <h4 class="card-title mb-0"><?php echo e(__('dashboard.payment_history')); ?></h4>
                <?php if(count($data['payment_history']) >= 5): ?>
                    <a id="payment_view_all_link" href="<?php echo e(route('backend.appointments.index')); ?>"
                        class="text-secondary d-none" contenteditable="false"
                        style="cursor: pointer;"><?php echo e(__('dashboard.view_all')); ?></a>
                <?php endif; ?>
            </div>
            <div class="card-body pt-0">
                <div class="table-responsive rounded bg-body">
                    <table class="table border m-0">
                        <thead>
                            <tr class="bg-body">
                                <th scope="col" class="heading-color"><?php echo e(__('sidebar.patient')); ?></th>
                                <th scope="col" class="heading-color"><?php echo e(__('messages.date_time')); ?></th>
                                <th scope="col" class="heading-color"><?php echo e(__('clinic.singular_title')); ?></th>
                                <th scope="col" class="heading-color"><?php echo e(__('messages.service')); ?></th>
                                <th scope="col" class="heading-color"><?php echo e(__('appointment.price')); ?></th>
                                <th scope="col" class="heading-color"><?php echo e(__('earning.lbl_payment_method')); ?></th>
                                <th scope="col" class="heading-color"><?php echo e(__('appointment.lbl_payment_status')); ?></th>
                            </tr>
                        </thead>
                        <tbody id="payment_history_table_body">
                            <?php $__empty_1 = true; $__currentLoopData = $data['payment_history']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymenthistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $transaction = $paymenthistory->appointmenttransaction;

                                    if ($transaction) {
                                        if ($transaction->payment_status == 1) {
                                            $payment_status = __('dashboard.paid');
                                        } elseif (
                                            $transaction->payment_status == 0 &&
                                            $transaction->advance_payment_status == 1
                                        ) {
                                            $payment_status = __('dashboard.advance_paid');
                                        } else {
                                            $payment_status = __('dashboard.pending');
                                        }
                                    }
                                ?>

                                <?php if($transaction): ?>
                                    <tr>
                                        <td><?php echo e(optional($paymenthistory->user)->full_name); ?></td>
                                        <td><?php echo e(date($data['dateformate'], strtotime($paymenthistory->appointment_date))); ?>

                                            At
                                            <?php echo e(date($data['timeformate'], strtotime($paymenthistory->appointment_time))); ?>

                                        </td>
                                        <td><?php echo e(optional($paymenthistory->cliniccenter)->name); ?></td>
                                        <td><?php echo e(optional($paymenthistory->clinicservice)->name); ?></td>
                                        <td><?php echo e(Currency::format($transaction->total_amount)); ?></td>
                                        <td><?php echo e(ucfirst($transaction->transaction_type)); ?></td>
                                        <td><?php echo e($payment_status); ?></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan="6">
                                        <?php echo e(__('messages.payment_history_notavailable')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-styles'); ?>
    <style>
        .list-group {
            --bs-list-group-item-padding-y: 1.5rem;
            --bs-list-group-color: inherit !important;
        }

        .date-calender {
            display: flex;
            justify-content: space-between;
        }

        .date-calender .date {
            width: 12%;
            display: flex;
            align-items: center;
            flex-direction: column
        }

        .upcoming-appointments {
            min-height: 23.5rem;
            max-height: 23.5rem;
            overflow-y: scroll;
        }

        .register-vendors-list {
            height: 22rem;
            overflow-y: auto;
        }

        .iq-upcomming {
            display: flex !important;
            justify-content: center;
            align-items: center;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.40.0/apexcharts.min.css"
        integrity="sha512-tJYqW5NWrT0JEkWYxrI4IK2jvT7PAiOwElIGTjALSyr8ZrilUQf+gjw2z6woWGSZqeXASyBXUr+WbtqiQgxUYg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
<?php $__env->stopPush(); ?>
<?php $__env->startPush('after-scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/apexcharts/3.40.0/apexcharts.min.js"
        integrity="sha512-Kr1p/vGF2i84dZQTkoYZ2do8xHRaiqIa7ysnDugwoOcG0SbIx98erNekP/qms/hBDiBxj336//77d0dv53Jmew=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const dateInput = document.getElementById('revenuedateRangeInput');
            const submitBtn = document.getElementById('submitBtn');
            const form = document.getElementById('dateRangeForm');

            function isValidDateRange(dateRange) {
                const datePattern = /^\d{4}-\d{2}-\d{2} to \d{4}-\d{2}-\d{2}$/;
                return datePattern.test(dateRange.trim());
            }

            function toggleSubmitButton() {
                if (isValidDateRange(dateInput.value)) {
                    submitBtn.removeAttribute('disabled');
                } else {
                    submitBtn.setAttribute('disabled', 'disabled');
                }
            }

            dateInput.addEventListener('input', toggleSubmitButton);

            form.addEventListener('submit', function(event) {
                event.preventDefault();
                if (isValidDateRange(dateInput.value)) {
                    const encodedDateRange = encodeURIComponent(dateInput.value);
                    const formAction = `<?php echo e(url('app/daterange')); ?>/${encodedDateRange}`;
                    window.location.href = formAction;
                }
            });

            toggleSubmitButton();
        });
        $(document).ready(function() {
            Scrollbar.init(document.querySelector('.upcoming-appointments'), {
                continuousScrolling: false,
                alwaysShowTracks: false
            })
            const range_flatpicker = document.querySelectorAll('.dashboard-date-range');
            Array.from(range_flatpicker, (elem) => {
                if (typeof flatpickr !== typeof undefined) {
                    flatpickr(elem, {
                        mode: "range",
                    })
                }
            })

        })

        revanue_chart('Year')


        var dateRangeValue = $('#revenuedateRangeInput').val();



        if (dateRangeValue != '') {
            var dates = dateRangeValue.split(" to ");
            var startDate = dates[0];
            var endDate = dates[1];

            if (startDate != null && endDate != null) {
                revanue_chart('Free', startDate, endDate);
                $('#refreshRevenuechart').removeClass('d-none');
                $('#date_range').addClass('d-none');
            }
        } else {
            revanue_chart('Year');
            $('#refreshRevenuechart').addClass('d-none');
            $('#date_range').removeClass('d-none');
        }

        $('#refreshRevenuechart').on('click', function() {
            $('#revenuedateRangeInput').val('');
            revanue_chart('Year');
            $('#date_range').removeClass('d-none');
        });



        var chart = null;
        let revenueInstance;

        function revanue_chart(type, startDate, endDate) {
            var Base_url = "<?php echo e(url('/')); ?>";
            var url = Base_url + "/app/get_revnue_chart_data/" + type;

            $("#revenue_loader").show();


            $.ajax({
                url: url,
                method: "GET",
                data: {
                    start_date: startDate,
                    end_date: endDate
                },
                success: function(response) {
                    $("#revenue_loader").hide();
                    $(".total_revenue").text(type);
                    if (document.querySelectorAll('#total-revenue').length) {
                        const variableColors = IQUtils.getVariableColor();
                        const colors = [variableColors.primary, variableColors.info];
                        const monthlyTotals = response.data.chartData;
                        const category = response.data.category;
                        const options = {
                            series: [{
                                name: "<?php echo e(__('messages.total_revenue')); ?>",
                                data: monthlyTotals
                            }],
                            chart: {
                                fontFamily: '"Inter", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"',
                                height: 300,
                                type: 'area',
                                toolbar: {
                                    show: false
                                },
                                sparkline: {
                                    enabled: false,
                                },
                            },
                            colors: colors,
                            dataLabels: {
                                enabled: false
                            },
                            stroke: {
                                curve: 'smooth',
                                width: 3,
                            },
                            yaxis: {
                                show: true,
                                labels: {
                                    show: true,
                                    style: {
                                        colors: "#8A92A6",
                                    },
                                    offsetX: -15,
                                    formatter: function(value) {
                                        // Format the value with currency symbol
                                        return new Intl.NumberFormat('<?php echo e(app()->getLocale()); ?>', {
                                            style: 'currency',
                                            currency: '<?php echo e(GetcurrentCurrency()); ?>'
                                        }).format(value);
                                    }
                                },
                            },
                            legend: {
                                show: false,
                            },
                            xaxis: {
                                labels: {
                                    minHeight: 22,
                                    maxHeight: 22,
                                    show: true,
                                },
                                lines: {
                                    show: false
                                },
                                categories: category
                            },
                            grid: {
                                show: true,
                                borderColor: 'var(--bs-body-bg)',
                                strokeDashArray: 0,
                                position: 'back',
                                xaxis: {
                                    lines: {
                                        show: true
                                    }
                                },
                                yaxis: {
                                    lines: {
                                        show: true
                                    }
                                },
                            },
                            fill: {
                                type: 'solid',
                                opacity: 0
                            },
                            tooltip: {
                                enabled: true,
                                y: {
                                    formatter: function(value) {
                                        // Format tooltip values with currency symbol
                                        return new Intl.NumberFormat('<?php echo e(app()->getLocale()); ?>', {
                                            style: 'currency',
                                            currency: '<?php echo e(GetcurrentCurrency()); ?>'
                                        }).format(value);
                                    }
                                }
                            },
                        };

                        if (revenueInstance) {
                            revenueInstance.updateOptions(options);
                        } else {
                            revenueInstance = new ApexCharts(document.querySelector("#total-revenue"), options);
                            revenueInstance.render();
                        }
                    }
                }
            })
        };

        $(document).on('click', '.revenue-dropdown-item', function() {
            var type = $(this).data('type');
            $('#revenuedateRangeInput').val('');
            revanue_chart(type);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', ['isBanner' => false], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\yashodhahms\resources\views/backend/dashboard/index.blade.php ENDPATH**/ ?>