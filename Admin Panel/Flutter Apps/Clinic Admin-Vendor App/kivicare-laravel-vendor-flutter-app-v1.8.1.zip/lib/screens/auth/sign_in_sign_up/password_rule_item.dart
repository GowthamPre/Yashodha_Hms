import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';

class PasswordRuleItem extends StatelessWidget {
  final bool isValid;
  final String text;

  const PasswordRuleItem({super.key, required this.isValid, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          isValid ? Icons.check_circle : Icons.cancel,
          size: 16,
          color: isValid ? Colors.green : Colors.red,
        ),
        SizedBox(width: 8),
        Text(text, style: primaryTextStyle(size: 12)),
      ],
    );
  }
}
